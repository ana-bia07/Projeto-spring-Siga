package br.gov.sp.cps.ProjetoSpringIoC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSpringIoCApplicationTests {

	@Test
	void contextLoads() {
	}

}
